package no.ntnu.prog2007.assignment2

data class GroceryListItem(val description: String, var selected: Boolean = false)